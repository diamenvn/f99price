<div id="modal" class="modal right fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body p-0 overflow-auto d-flex flex-column">
                <div class="p2">Đang tải dữ liệu ...</div>
            </div>
        </div>
    </div>
</div>