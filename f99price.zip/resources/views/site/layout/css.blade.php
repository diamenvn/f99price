<link rel="stylesheet" href="{{asset('assets/css/app.css')}}">

<!-- BOOTSTRAP -->
<link rel="stylesheet" href="{{asset('assets/css/bootstrap/bootstrap.min.css')}}">

<!-- JQUERY CONFIRM -->
<link rel="stylesheet" href="{{asset('assets/vendor/jquery-confirm/dist/style.min.css')}}">


<!-- VENDOR -->
<link rel="stylesheet" href="{{asset('assets/css/vendor.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/filepond.css')}}">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<link href="{{asset('assets/vendor/gridjs/mermaid.min.css')}}" rel="stylesheet" />

<link href="{{asset('assets/vendor/notify/notiflix-2.7.0.min.css')}}" rel="stylesheet" />