<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title><?php echo e(isset($title) ? $title : ($shopSetting->title ?? "")); ?> - F99 Price</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" /><?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/layout/head.blade.php ENDPATH**/ ?>