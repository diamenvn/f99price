<aside class="sidebar sidebar--left sidebar--left--min <?php echo e($sidebarLeft ?? ''); ?>">
    <div class="sidebar__logo">
        <img src="https://websitemisa.misacdn.net/sites/logo/misa-mtax.svg" alt="">
        <span class="fw-bold ml-2 brand_name">Data warehouse</span>
    </div>
    <div class="sidebar__menu__lists d-flex flex-column justify-content-between flex-1">
        <div class="sidebar__menu__top">
            <div class="sidebar__menu__item <?php echo e(setActive('site.home.dashboard')); ?>">
                <a href="<?php echo e(route('site.home.dashboard', ['brand_id' => app('request')->input('brand_id')])); ?>"><div class="mi mi-24 mi-sidebar-dashboard"></div><span>Tổng quan</span></a>
            </div>
            <div class="sidebar__menu__item <?php echo e(setActive('crawl_pages.index')); ?>">
                <a href="<?php echo e(route('crawl_pages.index', ['brand_id' => app('request')->input('brand_id')])); ?>"><div class="mi mi-24 mi-sidebar-script"></div><span>Lấy dữ liệu</span></a>
            </div>
            <div class="sidebar__menu__item <?php echo e(setActive('sync_pages.index')); ?>">
                <a href="<?php echo e(route('sync_pages.index', ['brand_id' => app('request')->input('brand_id')])); ?>"><div class="mi mi-24 mi-sidebar-script"></div><span>Đẩy dữ liệu</span></a>
            </div>
            <div class="sidebar__menu__item <?php echo e(setActive('config.index')); ?>">
                <a href="<?php echo e(route('config.index', ['brand_id' => app('request')->input('brand_id')])); ?>"><div class="mi mi-24 mi-sidebar-setting"></div><span>Cấu hình</span></a>
            </div>
            <div class="sidebar__menu__item <?php echo e(setActive('setting.index')); ?>">
                <a href="<?php echo e(route('setting.index', ['brand_id' => app('request')->input('brand_id')])); ?>"><div class="mi mi-24 mi-sidebar-account"></div><span>Tài khoản</span></a>
            </div>
        </div>
    </div>
</aside><?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/sidebar/left.blade.php ENDPATH**/ ?>