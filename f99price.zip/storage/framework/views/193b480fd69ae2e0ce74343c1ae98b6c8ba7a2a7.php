<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">

<!-- BOOTSTRAP -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap/bootstrap.min.css')); ?>">

<!-- JQUERY CONFIRM -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-confirm/dist/style.min.css')); ?>">


<!-- VENDOR -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/filepond.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<link href="<?php echo e(asset('assets/vendor/gridjs/mermaid.min.css')); ?>" rel="stylesheet" />

<link href="<?php echo e(asset('assets/vendor/notify/notiflix-2.7.0.min.css')); ?>" rel="stylesheet" /><?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/layout/css.blade.php ENDPATH**/ ?>