

<?php $__env->startSection('content'); ?>
    <div class="my-3">
        <div class="row">
            <div class="col">
                <?php echo $__env->make("site.dashboard.summary", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="title-primary">Lấy dữ liệu gần đây nhất</div>
                        <div id="chart"></div>
                    </div>
                    <div class="col-12">
                        <div class="title-primary">Đồng bộ gần đây nhất</div>
                        <div id="chart-2"></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_js'); ?>
    <script>
        var data = [];
        var label = [];
        <?php if(isset($charts) && count($charts) > 0): ?>
            <?php $__currentLoopData = $charts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                data.push('<?php echo e($chart['count'] ?? 0); ?>');
                label.push('<?php echo e($chart['domain']); ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        var options = {
            series: [{
                name: 'Số lượng bài viết',
                type: 'column',
                data: data
            }],
            chart: {
                height: 300,
                type: 'area',
            },
            stroke: {
                width: [0, 4]
            },
            dataLabels: {
                enabled: true,
                enabledOnSeries: [1]
            },
            labels: label,
            xaxis: {
                type: 'text'
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();


        var data = [];
        var label = [];
        <?php if(isset($recentSync) && count($recentSync) > 0): ?>
            <?php $__currentLoopData = $recentSync; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                data.push('<?php echo e($chart['config']['log']['count_post_sync_success'] ?? 0); ?>');
                label.push('<?php echo e($chart['domain']); ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        var options = {
            series: [{
                name: 'Số lượng bài viết',
                type: 'column',
                data: data
            }],
            chart: {
                height: 300,
                type: 'area',
            },
            stroke: {
                width: [0, 4]
            },
            dataLabels: {
                enabled: true,
                enabledOnSeries: [1]
            },
            labels: label,
            xaxis: {
                type: 'text'
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart-2"), options);
        chart.render();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/dashboard/index.blade.php ENDPATH**/ ?>