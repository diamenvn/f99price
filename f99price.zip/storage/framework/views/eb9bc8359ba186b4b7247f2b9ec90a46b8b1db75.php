<!-- Fontawesome 5 -->
<script src="<?php echo e(asset('assets/vendor/font-awesome-5/js/all.js')); ?>"></script>

<!-- JQUERY -->
<script src="<?php echo e(asset('assets/vendor/jquery/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery/sortable.js')); ?>"></script>

<!-- BOOTSTRAP -->
<script src="<?php echo e(asset('assets/js/bootstrap/bootstrap.min.js')); ?>"></script>

<!-- JQUERY CONFIRM -->
<script src="<?php echo e(asset('assets/vendor/jquery-confirm/dist/jquery-confirm.min.js')); ?>"></script>

<!-- CUSTOM -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

<!-- FILEPOND -->
<script src="<?php echo e(asset('assets/vendor/filepond/filepond.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/filepond/filepond-preview-image.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/filepond/filepond-jquery.min.js')); ?>"></script>

<!-- SIMPLE MONEY FORMAT -->
<script src="<?php echo e(asset('/assets/vendor/format_number/simple.format.number.js')); ?>"></script>

<!-- APEX CHART -->
<script src="<?php echo e(asset('/assets/vendor/apexchart/chart.js')); ?>"></script>

<script src="<?php echo e(asset('/assets/vendor/gridjs/gridjs.production.min.js')); ?>"></script>

<!-- AXIOS -->
<script src="<?php echo e(asset('/assets/vendor/axios/axios.min.js')); ?>"></script>


<!-- NOTIFLIX -->
<script src="<?php echo e(asset('/assets/vendor/notify/notiflix.min.js')); ?>"></script>


<?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/layout/js.blade.php ENDPATH**/ ?>