<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('site.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Đăng ký</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <div class="main main--layout w-100">
        <div class="layout__bg-wrapper login h-100">
            <div class="container-fluid">
                <div class="row full-height-vh m-0">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <div class="card">
                            <div class="card-content">
                                <div class="card-body login-img">
                                    <form action="<?php echo e(route('auth.postRegister')); ?>" method="POST" class="row m-0">
                                        <div class="col-lg-6 d-lg-block d-none py-2 px-3 text-center align-middle"><img alt="" class="img-fluid mt-5" height="230" src="<?php echo e(asset('assets/images/login.png')); ?>" width="400"></div>
                                        <div class="col-lg-6 col-md-12 bg-white px-4 pt-3">
                                            <h4 class="card-title mb-2">Đăng ký</h4>
                                            <p class="card-text mb-4">Vui lòng nhập đầy đủ thông tin bên dưới</p>

                                            <input class="form-control mb-3" name="username" placeholder="Tài khoản" type="text" required>
                                            <input class="form-control mb-3" name="email" placeholder="Địa chỉ mail" type="mail" required>
                                            <input name="password" class="form-control mb-3" placeholder="Mật khẩu" type="password" required>
                                            <input name="re-password" class="form-control mb-3" placeholder="Nhập lại mật khẩu" type="password" required>

                                            <div class="d-flex justify-content-between mt-">
                                                <div class="remember-me">
                                                    
                                                </div>
                                                <div class="forgot-password-option"><a class="text-decoration-none text-primary" href="/login">Đăng nhập ngay</a></div>
                                            </div>
                                            <div class="fg-actions d-flex justify-content-end mt-3">
                                                <div class="recover-pass">
                                                    <div class="btn btn-primary btn-register-js pointer"><a class="text-decoration-none text-white">Đăng ký</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <?php if(!empty($error)): ?>
                                    <div class="bottom bg-danger fs-14 p-1 px-2 co-white">
                                        <?php echo e($error); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(!empty($success)): ?>
                                <div class="bottom bg-success fs-14 p-1 px-2 co-white">
                                    <?php echo e($success); ?>

                                </div>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/auth/register.blade.php ENDPATH**/ ?>