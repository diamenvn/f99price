<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('site.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="wrapper wrapper--layout">
        <?php echo $__env->make('site.sidebar.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('site.sidebar.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="site-main blur d-flex flex-column overflow-hidden">
            <header class="header header--layout d-flex justify-content-between">
                <div class="header__left d-flex align-items-center">
                    <div class="header__item">
                        <?php if(isset($detail)): ?>
                            <div class="header__current__db">
                                Dữ liệu <?php echo e($detail->domain); ?>

                            </div>
                        <?php elseif(isset($title)): ?>
                            <div class="header__current__db">
                                <?php echo e($title); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="header__right d-flex">
                    <div class="header__item">
                        <div class="header__profie d-flex align-items-center">
                            <div class="header__item__avatar">
                                <img class="br-50" src="<?php echo e(asset('assets/images/getavatar.png')); ?>" alt="">
                            </div>
                            <div class="header__item__name">User</div>
                        </div>
                    </div>
                </div>
            </header>
            
            <section class="main-content flex-1 overflow-auto d-flex flex-column container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
</body>

</html>
<?php echo $__env->make('site.layout.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('site.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('custom_js'); ?>
<?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/layout/app.blade.php ENDPATH**/ ?>