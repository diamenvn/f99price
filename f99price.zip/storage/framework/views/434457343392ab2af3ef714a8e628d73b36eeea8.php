<div class="form-header">
    <h5 class="m-0"><i class="fal fa-plus-circle"></i> <?php echo e(isset($detail) ? 'Chỉnh sửa kết nối' : 'Thêm kết nối mới'); ?></h5>
</div>
<form id="form_add_page" action="<?php echo e(isset($detail) ? route('config.update', $detail->_id) : route('config.store')); ?>" method="<?php echo e(isset($detail) ? "PUT" : "POST"); ?>" class="form_submit_ajax-js flex-1 overflow-auto mt-2">
    <?php echo csrf_field(); ?>
    <div class="container-fluid">
        <div class="row">
            <?php if(!isset($detail)): ?>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Nguồn dữ liệu</label>
                        <select name="crawl_site_id" class="form-control">
                            <?php $__currentLoopData = $crawl_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->_id); ?>"><?php echo e($site->domain); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Đồng bộ đến</label>
                        <select name="sync_site_id" class="form-control">
                            <?php $__currentLoopData = $sync_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->_id); ?>"><?php echo e($site->domain); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Trạng thái</label>
                        <select name="status" <?php if($detail->status == 2): ?> disabled <?php endif; ?> class="form-control">
                            <option <?php if($detail->status == 1): ?> selected="selected" <?php endif; ?> value="1">Hoạt động</option>
                            <option <?php if($detail->status == 0): ?> selected="selected" <?php endif; ?> value="0">Tạm dừng</option>
                        </select>
                        <?php if($detail->status == 2): ?> <span class="text text--danger fs-12">Đang tạm dừng do lỗi xác thực username, vui lòng kiểm tra lại</span> <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-12">
                <div class="form-group">
                    <label for="">Thời gian đồng bộ mỗi lần (phút) - <i>Mặc định <?php echo e(config("app.sync_time_step")); ?> phút</i></label>
                    <input type="number" name="time_step" class="form-control" placeholder="Nhập thời gian" value="<?php echo e($detail->time_step ?? ""); ?>">
                </div>
            </div>
        </div>
    </div>
</form>
<div class="form-footer p-3">
    <div class="row">
        <div class="col-12">
            <button class="btn btn-primary--custom d-inline-block w-100 submit_form-js" data-form="#form_add_page"><i
                    class="fal fa-save"></i> <?php echo e(isset($detail) ? 'Cập nhật' : 'Thêm mới'); ?></button>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Documents\Source Code\f99price\resources\views/site/config/form.blade.php ENDPATH**/ ?>