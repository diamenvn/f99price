<?php

return [
    'token' => env('TELEGRAM_TOKEN'),
    'chat_id' => env('TELEGRAM_CHAT_ID')
];